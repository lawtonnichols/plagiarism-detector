/* See license.txt for terms of usage */

var EXPORTED_SYMBOLS=['debuggerHalter'];

function debuggerHalter()
{
    debugger;
}